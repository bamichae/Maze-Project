////////////////////////////////////////////////////////////////////////////////////////////////
//
// File name         : maze.cpp
//
// This file holds the definition for the maze class
//
// Programmer        : Ben Michaels
//
// Date created      : 4 / 5 / 2015
//
// Date last revised : 5/5/2015
//
////////////////////////////////////////////////////////////////////////////////////////////////


#include "maze.h"

#include <iostream>
#include <string>
#include <fstream>
#include <queue>

#include <stack>

#include <list>


using namespace std;


//////////////////////////////////////////////////////////////////////////////////////////
//
// function name      : Maze()
//
// purpose            : constructor
//
// input parameters   : none
//
// output parameters  : none
//
// return value       : none
//
/////////////////////////////////////////////////////////////////////////////////////////
Maze::Maze()
{
	for (int i = 0; i < 22; i++)
	{
		for (int j = 0; j < 22; j++)
		{
			floor[i][j] = '0';    // 22X22 array 
			floor2[i][j] = '0';  // floor

		}
	}
	 
	for (int i = 0; i < 22; i++){
		for (int j = 0; j < 22; j++)
		{
			board[i][j] = 0;
		}
	}
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// function name      : Maze
//
// purpose            : cc
//
// input parameters   : none
//
// output parameters  : none
//
// return value       : none
//
/////////////////////////////////////////////////////////////////////////////////////////

Maze::Maze(Maze& initM)
{


}

//////////////////////////////////////////////////////////////////////////////////////////
//
// function name      : ~Maze
//
// purpose            : destructor
//
// input parameters   : none
//
// output parameters  : none
//
// return value       : none
//
/////////////////////////////////////////////////////////////////////////////////////////

Maze::~Maze()
{

}
//////////////////////////////////////////////////////////////////////////////////////////
//
// function name      : readIn
//
// purpose            : reads in
//
// input parameters   : none
//
// output parameters  : none
//
// return value       : none
//
/////////////////////////////////////////////////////////////////////////////////////////

void Maze::readIn()
{
	

		string inFileName;
		ifstream inFile;
		char c;

		cout << "\n Please enter the fully qualified name of\n"
			<< "the input text file, including the path:\n";

		cin >> inFileName;

		cout << endl;

		inFile.open(inFileName.c_str(), ios::in);                                    //try to open

		if (!inFile)                                                      //test if open
		{
			cerr << " cannot open file: " << inFileName << endl << endl;
			exit(-1);
		}

		
		for (int i = 1; i < 11; i++)
		{
			for (int j = 1; j < 11; j++)    // loops through
			{
				inFile >> c;
				floor[i][j] = c;
				
				if (floor[i][j] == 48)
					board[i][j] = 0;
				else if (floor[i][j] == 49)
					board[i][j] = 1;
				else if (floor[i][j] == 'E')
					board[i][j] = 2;
			
			
			}
			
		}
	

		
		for (int i = 0; i < 12; i++)                   // nested for loop
		{

			for (int j = 0; j < 12; j++)              // for array of 22x22
			{
				

				if (i == 0 && j == 0)
					floor[i][j] = a;
				else if (i == 0 && j == 11)           // defining borders
					floor[i][j] = b;
				else if (i == 11 && j == 0)
					floor[i][j] = c;
				else if (i == 11 && j == 11)
					floor[i][j] = d;
				else if (i == 0 && j != 0 && j != 11 || i == 11 && j != 0 && j != 11)
					floor[i][j] = e;
				else if (j == 0 && i != 0 && i != 11 || j == 11 && i != 0 && i != 11)
					floor[i][j] = f;

				floor2[i][j] = floor[i][j];

				if (floor[i][j] != 49 && floor[i][j] != 48 && floor[i][j] != 'E')
					board[i][j] = 1;

			}
		}

}


//////////////////////////////////////////////////////////////////////////////////////////
//
// function name      : floorBoard()
//
// purpose            : Write out the floorboard
//
// input parameters   : none
//
// output parameters  : none
//
// return value       : none
//
/////////////////////////////////////////////////////////////////////////////////////////

void Maze::floorBoard()
{


	cout << "\n\n   12345678910";
	for (int i = 0; i < 12; i++)                   // nested for loop
	{
		cout << endl;
		if (i > 0 && i < 11 && i != 10)
		{
			cout << i << " ";
		}
		else if (i == 10)
		{
			cout << i;
		}
		for (int j = 0; j < 12; j++)              // for array of 22x22
		{
			if (i == 11 && j == 0 || i == 0 && j == 0)
				cout << "  ";
			
			if (i == 0 && j == 0)
				floor[i][j] = a;
			else if (i == 0 && j == 11)           // defining borders
				floor[i][j] = b;
			else if (i == 11 && j == 0)
				floor[i][j] = c;
			else if (i == 11 && j == 11)
				floor[i][j] = d;
			else if (i == 0 && j != 0 && j != 11 || i == 11 && j != 0 && j != 11)
				floor[i][j] = e;
			else if (j == 0 && i != 0 && i != 11 || j == 11 && i != 0 && i != 11)
				floor[i][j] = f;
			

			if (floor[i][j] != 49 && floor[i][j] != 48 && floor[i][j] != 'E')
				board[i][j] = 1;

			if (floor[i+1][j] != '*' && floor[i-1][j] != '*' && floor[i][j+1] != '*' && floor[i][j-1] != '*' && floor[i][j] == '*')
				floor[i][j] = '0';
			cout << floor[i][j];
			

		}
	}
}

	//////////////////////////////////////////////////////////////////////////////////////////
	//
	// function name      : chooseStart
	//
	// purpose            : finds start
	//
	// input parameters   : none
	//
	// output parameters  : none
	//
	// return value       : none
	//
	/////////////////////////////////////////////////////////////////////////////////////////

void Maze::chooseStart()
{

	int x;
	int y;
	bool flag = false;


	do{
		flag = false;
		
		cout << "\nWhat coordinate would you like to start at?\n";
		cout << "The coordinate (1,10) is the top right of the maze\n\n";


		cout << " Pick an x coordinate (x,y) from 1 to 10: \n";
		do{
			cin >> x;
			if (x < 1 || x > 10)
			cout << "\nInvalid entry. Enter again.\n";  // enter
		} while (x < 1 || x > 10);
		
		cout << "\nYou chose: " << x << endl;

		cout << " Pick a y coordinate (x,y) from 1 to 10: \n";
		
		
		do{cin >> y;
		if (y < 1 || y > 10)
			cout << "\nInvalid entry. Enter again.\n";     //enter
		} while (y < 1 || y > 10);
		
		cout << "\nYou chose: " << y;
		
		
		if (board[x][y] ==1)
		{ 
			cout << "\nYou cannot start inside of a wall.\n";   // error check
			flag = true;
		}
		

		if (!flag)   // error check
		{
			xCd = x;
			yCd = y;
		}
	} while (board[x][y] != 0);



}




//////////////////////////////////////////////////////////////////////////////////////////
//
// function name      : searchMaze
//
// purpose            : to search maze
//
// input parameters   : none
//
// output parameters  : none
//
// return value       : none
//
/////////////////////////////////////////////////////////////////////////////////////////

void Maze::searchMaze()
{
	coord C;
	list<coord> l;
	coord* stackPtr = NULL;
	int stuck = 0;
	int emergency = 0;
	list<coord> temp;
	list<coord>::iterator it;
	list<coord>::iterator anIt;
	coord T;
	list<coord> temp2;
	list<coord> temp3;



	
	int x = getxPos();
	int y = getyPos();

	

		C.x = x;
		C.y = y;
		S1.push(C);   // push 

		
		while (!stuck)
		{
			emergency = 0;
			

			stackPtr = &S1.top();   // point to top
			T.x = stackPtr->x;
			T.y = stackPtr->y;   // assign valeus

			temp3.push_back(T);
			temp2.push_back(T);
			temp.push_back(T);
			

			setX(stackPtr->x);
			setY(stackPtr->y);

			

			for (it = L1.begin(); it != L1.end(); it++)
			{	

				if ((stackPtr->x == it->x) && (stackPtr->y == it->y))   // loop through and pop if in the list
				{
					S1.pop();
					if (S1.empty())
					{
						cout << "\n\nHELP I'M STUCK!!!\n";    // if empty, stuck

						L1.clear();
						temp.clear();
						temp2.clear();
						temp3.clear();
						while (!S1.empty())
							S1.pop();

						stackPtr = NULL;
						emergency = 1;
						break;
						
					}
					stackPtr = &S1.top();
				}
			
			

			}


			if (emergency)
				break;

			C.x = stackPtr->x;   // assign
			C.y = stackPtr->y;
			L1.push_back(C);

			x = getxPos();
			y = getyPos();




			if (checkRight(x, y) == 2 || checkLeft(x, y) == 2 || checkUp(x, y) == 2 || checkDown(x, y) == 2)
			{
				cout << "\nI am free!\n";
				break;
			}



			if (checkRight(x, y) == 0)  // check for left area
			{
				
				int i = 0;

				for (it = L1.begin(); it != L1.end(); it++)
				{
					i++;


					if ((it->x == x) && (it->y == (y + 1)))
						break;

					else if ((i == L1.size()))
					{
						C.x = x;
						C.y = y + 1;
						S1.push(C);
					}

				}


			}


			if (checkUp(x, y) == 0)    // check up area
			{
				
				int i = 0;

				for (it = L1.begin(); it != L1.end(); it++)
				{
					i++;

					if ((it->x == (x - 1)) && (it->y == y))
						break;

					else if ((i == L1.size()))
					{
						C.x = x - 1;
						C.y = y;
						S1.push(C);
					}

				}


			}

			if (checkLeft(x, y) == 0)   // check left area
			{
				int i = 0;

				
				for (it = L1.begin(); it != L1.end(); it++)
				{
					i++;

					if ((it->x == x) && (it->y == (y - 1)))
						break;

					else if ((i == L1.size()))
					{
					
						C.x = x;
						C.y = y - 1;
						S1.push(C);
					}

				}


			}



			if (checkDown(x, y) == 0)      // cheack down area
			{
				int i = 0;
				

				for (it = L1.begin(); it != L1.end(); it++)
				{
					i++;

					if ((it->x == (x + 1)) && (it->y == y))
						break;

					else if ((i == L1.size()))
					{
						C.x = x + 1;
						C.y = y;
						S1.push(C);
					}

				}


			}

		}
		if (!emergency){

			

			int count = 0;
			list<coord>::iterator another;


			for (it = temp2.begin(); it != temp2.end(); it++)   // make a list
			{
				count = 0;
				for (anIt = temp3.begin(); anIt != temp3.end(); anIt++)   // and compare its valus
				{


					if ((it->x == anIt->x) && (it->y == anIt->y))  // if repeated values, trash those values
					{

						count++;


					}
					if (count > 1)
					{
						T.x = it->x;
						T.y = it->y;

						temp.remove(T);

					}
				}

			}

			for (another = temp.begin(); another != temp.end(); another++)
			{
			
				floor[another->x][another->y] = '*';   // put astrix in
			}
		

		}
		
	
		L1.clear();
		temp.clear();
		temp2.clear();
		temp3.clear();
		while (!S1.empty())
			S1.pop();

		stackPtr = NULL;
		
}


//////////////////////////////////////////////////////////////////////////////////////////
//
// function name      : getxPos
//
// purpose            : x
//
// input parameters   : none
//
// output parameters  : none
//
// return value       : int xCd
//
/////////////////////////////////////////////////////////////////////////////////////////

int Maze::getxPos()
{
	return xCd;
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// function name      : floorBoard(Direction& D, Pen& aPen)
//
// purpose            : Write out the floorboard
//
// input parameters   : none
//
// output parameters  : Direction& D, Pen& aPen
//
// return value       : none
//
/////////////////////////////////////////////////////////////////////////////////////////

int Maze::getyPos()
{
	return yCd;
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// function name      : check up
//
// purpose            : check
//
// input parameters   : none
//
// output parameters  : nne
//
// return value       : none
//
/////////////////////////////////////////////////////////////////////////////////////////

int Maze::checkUp(int x, int y)
{
	return board[x-1][y];

}

//////////////////////////////////////////////////////////////////////////////////////////
//
// function name      : checkDown
//
// purpose            : check down
//
// input parameters   : none
//
// output parameters  : none
//
// return value       : none
//
/////////////////////////////////////////////////////////////////////////////////////////

int Maze::checkDown(int x, int y)
{
	
	return board[x+1][y];

}

//////////////////////////////////////////////////////////////////////////////////////////
//
// function name      : checkLft
//
// purpose            : checks left
//
// input parameters   : none
//
// output parameters  : none
//
// return value       : none
//
/////////////////////////////////////////////////////////////////////////////////////////
int Maze::checkLeft(int x, int y)
{
	
	return board[x][y-1];

}

//////////////////////////////////////////////////////////////////////////////////////////
//
// function name      : check right
//
// purpose            : Write out the floorboard
//
// input parameters   : none
//
// output parameters  : none
//
// return value       : none
//
/////////////////////////////////////////////////////////////////////////////////////////
int Maze::checkRight(int x, int y)
{

	return board[x][y + 1];

}

//////////////////////////////////////////////////////////////////////////////////////////
//
// function name      : setX
//
// purpose            : sets x
//
// input parameters   : none
//
// output parameters  : none
//
// return value       : none
//
/////////////////////////////////////////////////////////////////////////////////////////
void Maze::setX(int x)
{
	xCd = x;
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// function name      : setY
//
// purpose            : sets Y
//
// input parameters   : none
//
// output parameters  : none
//
// return value       : none
//
/////////////////////////////////////////////////////////////////////////////////////////
void Maze::setY(int y)
{
	yCd = y;
}

//////////////////////////////////////////////////////////////////////////////////////////
//
// function name      : clearBoard
//
// purpose            : clears board
//
// input parameters   : none
//
// output parameters  : none
//
// return value       : none
//
/////////////////////////////////////////////////////////////////////////////////////////

void Maze::clearBoard()
{
	for (int i = 0; i < 12; i++)
	{
		for (int j = 0; j < 12; j++){
			floor[i][j] = floor2[i][j];
			if (floor2[i][j] != 49 && floor2[i][j] != 48 && floor2[i][j] != 'E')
				board[i][j] = 1;
		}

	}

}
