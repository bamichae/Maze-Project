/*************************************************************
**
** Programmer     : Ben Michaels
**
** Instructor     : Mr. Streller
**
** Course         : CS-132
**
** Date Created   : 4/4/2015
**
** Date Revised   : 5/5/2015
**
** Program Name   : Project3
**
** File Name      : client_driver.cpp
**
** Input Files    : maze_sample.txt
**
** Output Files   : none
**
** Purpose        : This program finds a way out of a maze
**                  
**
**
***************************************************************/


#include "maze.h"


#include <iostream>  // for i/o




using namespace std;



int main(){

	Maze M;
	M.readIn();

	while (true){

		M.floorBoard(); // call board
		M.chooseStart(); // find start
		M.searchMaze(); //search
		M.floorBoard(); // show
		M.clearBoard(); // clear
		
		
		
	}

	
	return 0;
} // end main