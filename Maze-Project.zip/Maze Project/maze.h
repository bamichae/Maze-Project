////////////////////////////////////////////////////////////////////////////////////////////////
//
// File name         : maze.h
//
// This file holds the header for the Maze class
//
// Programmer        : Ben Michaels
//
// Date created      : 4 / 5 / 2015
//
// Date last revised : 5/5/2015
//
////////////////////////////////////////////////////////////////////////////////////////////////

#ifndef MAZE_H
#define MAZE_H

#include <stack>
#include <list>


struct coord
{
	int x, y;

	bool operator ==(const coord right)  // overloaded equality operator
	{
		if (this->x == right.x && this->y == right.y)     // determine which is less than based on id number
			return true;
		else
			return false;
	}
};




class Maze {

public:

	std::stack <coord> S1;
	std::list <coord> L1;


	Maze(); // const
	Maze(Maze& initM);  // copy const
	~Maze();  // dest
	void floorBoard();  // floor
	char floor[22][22];    // 22X22 array 
	char floor2[22][22];  // floor
	void readIn();  // readin
	void chooseStart();  // choose the start
	int getxPos();  // get x
	int getyPos();
	void searchMaze();   // search algorithm
	int board[22][22];  // cahnge to ints
	int checkUp(int x, int y); // checkup
	int checkDown(int x, int y); // checkdown
	int checkLeft(int x, int y); // checkleft
	int checkRight(int x, int y); // checkrigt
	void setX(int x);  // setx
	void setY(int y);
	void clearBoard(); // clear

private:

	unsigned char a = 201, b = 187, c = 200, d = 188, e = 205, f = 186;  // ascii characters to write the board
	int whatRow;
	int whatColumn;
	int xCd;
	int yCd;
};



#endif 